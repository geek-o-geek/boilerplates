export let app_strings = {
    HOME_ROUTE: '/user',
    TWO_ZERO_ONE: '200',
    CRED_INCORRECT: 'Incorrect Credentials',
    NO_INTERNET_CONNECTION: 'No Internet Connection',
    ERROR_OCCURRED: 'An unexpected error occurred',
    IMAGE_REQUIRED: 'User image is required',
    INVALID_FORM: 'Invalid form submission',
    SUCCESS: 'Successfully done',
    DEF_IMAGE_URL: "assets/images/def-person-m.jpg",
    UPDATED: "Updated Successfully",
    FILE_SIZE: 20,
    FILENAME: 'report',
    XLS_EXTENSION: 'xls',
    TWO_ZERO_ZERO: 200
}