import { HttpInterceptor, HttpRequest, HttpHandler } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Router } from "@angular/router";
import { UserService } from '../_services/user.service'; 
import { app_strings } from '../_constants/app_strings';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(
        private userService: UserService, private router: Router) { }

    intercept(req: HttpRequest<any>, next: HttpHandler) {
       
        const secureReq = req.clone(
        );
        
        if (req.headers.get('NoAuthOther'))
            return next.handle(secureReq);

        const token = `${this.userService.getToken()}`    
        if (req.headers.get('noauth'))
            return next.handle(req.clone({
                headers: req.headers.set("Authorization", token)
            }));
        else {
           
            const clonedreq = req.clone({
                headers: req.headers.set("Authorization", token)
            });

            return next.handle(clonedreq).pipe(
                tap(
                    event => { },
                    err => {
                        if(err.error.message.length > 100){
                            this.userService.error(app_strings.ERROR_OCCURRED)
                            return
                        }
                        this.userService.error(err.error.message || app_strings.ERROR_OCCURRED)
                    }
                )
            );
        }
    }
}