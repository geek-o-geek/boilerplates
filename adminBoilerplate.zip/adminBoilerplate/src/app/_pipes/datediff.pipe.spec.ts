import { DatediffPipe } from './datediff.pipe';

describe('DatediffPipe', () => {
  it('create an instance', () => {
    const pipe = new DatediffPipe();
    expect(pipe).toBeTruthy();
  });
});
