import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment.prod";
import { BehaviorSubject } from "rxjs";
import { ToastrService } from "ngx-toastr";
import * as FileSaver from "file-saver";
import Swal from "sweetalert2";
import { app_strings } from "../_constants/app_strings";
import * as XLSX from "xlsx";
const EXCEL_TYPE =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
const EXCEL_EXTENSION = ".xlsx";
@Injectable({
  providedIn: "root",
})
export class UserService {
  base_url: string = environment.base_url;
  moduleName: string = "auth";
  userRoute: string = "api/user";
  adminRoute: string = "api/admin";
  userId: BehaviorSubject<any> = new BehaviorSubject(null);
  celebUserId: BehaviorSubject<any> = new BehaviorSubject(null);
  celebReqId: BehaviorSubject<any> = new BehaviorSubject(null);
  quizId: BehaviorSubject<any> = new BehaviorSubject(null);
  quizItem: BehaviorSubject<any> = new BehaviorSubject(null);
  celebRoute: string = "api/celeb";
  constructor(private http: HttpClient, private toastr: ToastrService) {}

  success(msg) {
    if (!msg) return;
    this.toastr.success(msg);
  }

  error(msg) {
    if (!msg) return;
    this.toastr.error(msg);
  }

  getToken() {
    return localStorage.getItem("accessToken");
  }

  isAuthenticated(): boolean {
    if (this.getToken()) {
      return true;
    } else {
      return false;
    }
  }

  confirmPopup(): Promise<any> {
    return Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    });
  }

  setuserId(id) {
    this.userId.next(id);
  }

  getuserId(): BehaviorSubject<any> {
    return this.userId;
  }

  download(
    byteArrays,
    contentType = "application/vnd.ms-excel",
    FILENAME = "report"
  ) {
    const blob = new Blob(byteArrays, { type: contentType });
    const blobUrl = URL.createObjectURL(blob);
    console.log(blobUrl);

    FileSaver.saveAs(
      blobUrl,
      FILENAME + "_export_" + new Date().getTime() + app_strings.XLS_EXTENSION
    );
  }

  public exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = {
      Sheets: { data: worksheet },
      SheetNames: ["data"],
    };
    const excelBuffer: any = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    FileSaver.saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  }
}
