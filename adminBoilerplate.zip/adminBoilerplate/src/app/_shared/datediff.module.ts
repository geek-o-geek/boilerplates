import { NgModule } from '@angular/core';
import { ModalModule } from "ngx-modal";
import { DatediffPipe } from '../_pipes/datediff.pipe';

@NgModule({
  declarations: [DatediffPipe],
  imports: [
    
  ],
  exports: [
    DatediffPipe
  ]
})
export class DatediffModule { }
