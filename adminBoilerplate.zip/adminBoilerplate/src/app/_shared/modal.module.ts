import { NgModule } from '@angular/core';
import { ModalModule } from "ngx-modal";

@NgModule({
  declarations: [],
  imports: [
    ModalModule
  ],
  exports: [
    ModalModule
  ]
})
export class CustomModalModule { }
