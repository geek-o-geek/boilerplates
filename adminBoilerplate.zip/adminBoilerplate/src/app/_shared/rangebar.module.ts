import { Ng5SliderModule } from 'ng5-slider';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [],
  imports: [
    Ng5SliderModule
  ],
  exports: [
    Ng5SliderModule
  ]
})
export class RangebarModule { }
