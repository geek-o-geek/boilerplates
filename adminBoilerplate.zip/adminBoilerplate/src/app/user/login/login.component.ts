import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/_services/user.service';
import { app_strings } from 'src/app/_constants/app_strings';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginFrmGrp: FormGroup
  constructor(private router: Router, private fb: FormBuilder, private userService: UserService) { }

  ngOnInit() {
    this.loginFrm()
  }

  loginFrm(){
    this.loginFrmGrp = this.fb.group({
      email: ['', Validators.compose([Validators.required, Validators.email])],
      password: ['', Validators.compose([Validators.required])]
    })
  }

  get f(){ return this.loginFrmGrp.controls }

  login(){
    if(this.loginFrmGrp.invalid){
      this.loginFrmGrp.markAsTouched()
      this.userService.error(app_strings.INVALID_FORM)
      return
    }
     const ob = {
       email: this.f.email.value,
       password: this.f.password.value
     }
     
     
  }

  goto(uri){
    if(!uri) return;

    this.router.navigateByUrl(uri)
  }
}
