export const environment = {
  production: true,
  base_url: ''
};
