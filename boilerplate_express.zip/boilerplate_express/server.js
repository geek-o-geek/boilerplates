if(process.env.NODE_ENV !== 'production'){
    require('dotenv').config()
}

const express = require("express")
const app = express()
const bcrypt = require("bcrypt")
const passport = require("passport")
const flash = require("express-flash")
const session = require("express-session")
const methodOverride = require("method-override")
const initializePassport = require("./passport-config")
const swaggerJsDoc = require("swagger-jsdoc")
const swaggerUi = require("swagger-ui-express")

const swaggerOptions = {
    swaggerDefinition: {
        info: {
            title: "API",
            description: "API information",
            contact: {
                name: "geekogeek"
            },
            servers: ["https://localhost:4000"]
        }
    },
    apis: ["server.js"]
}

const swaggerDocs = swaggerJsDoc(swaggerOptions)
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs))

let users = [{
    id: 1,
    email: "arjun@gmail.com",
    password: bcrypt.hashSync("a", 10)
}] 

initializePassport(
    passport,
    email => users.find(user => user.email === email),
    id => users.find(user => user.id === id)
)

app.set("view-engine", "ejs")
app.use(express.urlencoded({ extended: false }))
app.use(flash())
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false
}))
app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))

app.get("/", checkAuthenticated, (req, res) => {
    res.render("index.ejs", { name: req.user.name  })
})

app.get("/login", checkNotAuthenticated, (req, res) => {
    res.render("login.ejs")
}) 

/**
 * @swagger
 * /test:
 *  post:
 *      description: Use to login to account
 *      responses:
 *          '200':
 *              description: 'success'
 * 
 */ 

app.post("/login", passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: "/login",
    failureFlash: true
}))

app.get("/register", (req, res) => {
    res.render("register.ejs")
})

app.delete("/logout", (req, res) => {
    req.logout()
    res.redirect('/login')
}) 

function checkAuthenticated(req, res, next){
    if(req.isAuthenticated()){
        return next()
    }

    res.redirect("/login")
}

function checkNotAuthenticated(req, res, next){
    if(req.isAuthenticated()){
        return res.redirect("/")
    }
    next()
}

app.listen(4000, () => {
    console.log(`server listening at 4000`)
})